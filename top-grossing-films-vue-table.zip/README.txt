A Pen created at CodePen.io. You can find this one at https://codepen.io/AKGD/pen/ZygjGo.

 Search and sort top grossing movies using Vue grid.