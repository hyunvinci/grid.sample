A Pen created at CodePen.io. You can find this one at https://codepen.io/howard_oh_my_god/pen/JaYaMd.

 